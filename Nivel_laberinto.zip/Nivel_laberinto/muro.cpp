#include "muro.h"

Muro::Muro(qreal x, qreal y, const QString &rutaImagen) {

    QPixmap imagen(rutaImagen);

    // Verificar si la imagen se cargo correctamente
    if (!imagen.isNull()) {
        this->setPixmap(imagen);
        this->setPos(x, y);
    }
    else {
        // Si hay error entonces...
        qDebug() << "Error: No se pudo cargar la imagen desde la ruta" << rutaImagen;
    }

}

Muro::Muro(qreal x, qreal y, const QPixmap &Imagen){
    setPixmap(Imagen);
    setPos(x, y);
}
