#include "widget.h"
#include "soldado_otomano.h"
#include "muro.h"
#include "muro_verdadero.h"
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <QBrush>

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    //Creando la escena (esto va en nivel2.cpp)
    QGraphicsScene *Laberinto = new QGraphicsScene();

    QPixmap fondo(":/imagenex/fondo_mundo_2.png");

    QGraphicsPixmapItem *imagen_fondo = new QGraphicsPixmapItem(fondo);

    imagen_fondo->setPos(0, 0);

    //escalar la imagen de fondo
    //fondo = fondo.scaled(view.size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    Laberinto->addItem(imagen_fondo);

    //Agregando los muros de colisiones (verdaderos)
    Muro_verdadero *verdadero1 = new Muro_verdadero(683, 430, 100, 100);
    Laberinto->addItem(verdadero1);

    //Agregando al personaje principal
    soldado_otomano *personaje = new soldado_otomano();
    //posicion inicial
    personaje->setPos(100, 100);
    personaje->setFlag(QGraphicsItem::ItemIsFocusable);
    personaje->setFocus();

    // Adicionar el personaje a la escena
    Laberinto->addItem(personaje);

    //creando los muros de los bordes
    QPixmap arbol_original(":/imagenex/arbol_aereo_pino.png");
    QPixmap arbol_original2(":/imagenex/arbol_aereo.png");
    QPixmap arbol_escalado = arbol_original.scaled(1000, 100);
    QPixmap arbol_escalado_vertical = arbol_original2.scaled(120, 768);
    QPixmap arbol_escalado_vertical2 = arbol_original2.scaled(120, 384);

    Muro *borde_inferior = new Muro(0, 700, arbol_escalado);
    Muro *borde_inferior2 = new Muro(366, 700, arbol_escalado);
    Muro *borde_izquierdo = new Muro(0, 0, arbol_escalado_vertical);
    Muro *borde_izquierdo2 = new Muro(0, 368, arbol_escalado_vertical2);
    Muro *borde_derecho = new Muro(1246, 0, arbol_escalado_vertical);

    Laberinto->addItem(borde_inferior);
    Laberinto->addItem(borde_inferior2);
    Laberinto->addItem(borde_izquierdo);
    Laberinto->addItem(borde_izquierdo2);
    Laberinto->addItem(borde_derecho);


    //Agregar muros
    Muro *muro1 = new Muro(150, 630, ":/imagenex/piedra.png");
    Muro *muro2 = new Muro(683, 384, ":/imagenex/campamento.png");
    Muro *muro3 = new Muro(200, 100, ":/imagenex/arbol_aereo.png");
    Muro *muro4 = new Muro(0, 650, ":/imagenex/piedra.png");

    Laberinto->addItem(muro1);
    Laberinto->addItem(muro2);
    Laberinto->addItem(muro3);
    Laberinto->addItem(muro4);

    // la vista y sus dimensiones
    QGraphicsView view(Laberinto);
    view.setFixedSize(1366, 768); // dimensiones de la vista

    view.setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view.setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    view.show();//mostrar la vista

    //Widget w;
    //w.show();
    return a.exec();
}
