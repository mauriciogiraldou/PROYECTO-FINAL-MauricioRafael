#include "widget.h"
#include "escena.h"
#include "soldado_otomano.h"
#include "muro.h"
#include "muro_verdadero.h"
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <QBrush>

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QPixmap fondo(":/imagenex/fondo2_mundo2.png");

    QGraphicsPixmapItem *imagen_fondo = new QGraphicsPixmapItem(fondo);

    imagen_fondo->setPos(0, 0);

    //Creando la escena (esto va en nivel2.cpp)
    Escena *Laberinto = new Escena();

    //escalar la imagen de fondo
    //fondo = fondo.scaled(view.size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    Laberinto->addItem(imagen_fondo);

    //Agregando los muros de colisiones (verdaderos)
    Muro_verdadero *verdadero1 = new Muro_verdadero(244, 146, 100, 70);
    Muro_verdadero *verdadero2 = new Muro_verdadero(239, 556, 10, 20);
    Muro_verdadero *verdadero3 = new Muro_verdadero(1040, 235, 15, 20);
    Muro_verdadero *verdadero4 = new Muro_verdadero(690, 103, 20, 60);
    Muro_verdadero *verdadero5 = new Muro_verdadero(429, 648, 529, 60);

    Laberinto->addItem(verdadero1);
    Laberinto->addItem(verdadero2);
    Laberinto->addItem(verdadero3);
    Laberinto->addItem(verdadero4);
    Laberinto->addItem(verdadero5);

    Muro *muro6 = new Muro(650, 40, ":/imagenex/orban_canon.png");//el canon de Orban
    Laberinto->addItem(muro6);

    //Agregando al personaje principal
    soldado_otomano *personaje = new soldado_otomano();
    //posicion inicial
    personaje->setPos(50, 80);
    // Adicionar el personaje a la escena
    Laberinto->addItem(personaje);
    personaje->setFlag(QGraphicsItem::ItemIsFocusable);
    personaje->setFocus();

    //creando los muros de los bordes
    Muro *bordes = new Muro(0, 0, ":/imagenex/marco4.png");
    Laberinto->addItem(bordes);

    //Agregar muros
    Muro *muro1 = new Muro(150, 630, ":/imagenex/piedra.png");
    Muro *muro2 = new Muro(220, 70, ":/imagenex/campamento.png");
    Muro *muro3 = new Muro(200, 400, ":/imagenex/arbol_aereo.png");
    Muro *muro4 = new Muro(0, 650, ":/imagenex/piedra.png");
    Muro *muro5 = new Muro(1000, 70, ":/imagenex/arbol_aereo_pino.png");

    Laberinto->addItem(muro1);
    Laberinto->addItem(muro2);
    Laberinto->addItem(muro3);
    Laberinto->addItem(muro4);
    Laberinto->addItem(muro5);

    // la vista y sus dimensiones
    QGraphicsView view(Laberinto);
    view.setFixedSize(1366, 768); // dimensiones de la vista

    view.setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view.setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    view.show();//mostrar la vista

    //Widget w;
    //w.show();
    return a.exec();
}
