#ifndef MURO_H
#define MURO_H
//#include <QObject>
#include <QPixmap>
//#include <QMap>
#include <QGraphicsPixmapItem>
#include <QString>
#include <QDebug>
#include "soldado_otomano.h"

class Muro:public QGraphicsPixmapItem
{

public:

    Muro(qreal x, qreal y, const QString& rutaImagen);
    Muro(qreal x, qreal y, const QPixmap& Imagen); //Constructor sobrecargado

};

#endif // MURO_H
