#include "soldado_otomano.h"

soldado_otomano::soldado_otomano(): vidas(3) {
    QPixmap personaje_principal(":/imagenex/soldado_o_abajo.png");
    setPixmap(personaje_principal);
}

void soldado_otomano::keyPressEvent(QKeyEvent *event){

    if (event->key() == Qt::Key_A){
        setPixmap(QPixmap(":/imagenex/soldado_o_izquierda.png"));
        moveBy(-10, 0);
    }
    else if (event->key() == Qt::Key_D){
        setPixmap(QPixmap(":/imagenex/soldado_o_derecha.png"));
        moveBy(10, 0);
    }
    else if (event->key() == Qt::Key_W){
        setPixmap(QPixmap(":/imagenex/soldado_o_arriba.png"));
        moveBy(0, -10);
    }
    else if (event->key() == Qt::Key_S){
        setPixmap(QPixmap(":/imagenex/soldado_o_abajo.png"));
        moveBy(0, 10);
    }

}

