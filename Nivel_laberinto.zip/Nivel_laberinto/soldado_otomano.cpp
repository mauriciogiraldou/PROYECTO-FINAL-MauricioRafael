#include "soldado_otomano.h"

soldado_otomano::soldado_otomano(): vidas(3) {
    QPixmap personaje_principal("/imagenex/caballo_o_abajo.png");
    personaje_principal = personaje_principal.scaledToWidth(personaje_principal.width() * 0.78);
    setPixmap(personaje_principal);
}

void soldado_otomano::keyPressEvent(QKeyEvent *event){

    qreal x_anterior = x();
    qreal y_anterior = y();

    if (event->key() == Qt::Key_A){
        QPixmap pixmap(":/imagenex/caballo_o_izquierda.png");
        pixmap = pixmap.scaledToWidth(pixmap.width() * 0.78);
        setPixmap(pixmap);
        moveBy(-10, 0);
    }
    else if (event->key() == Qt::Key_D){
        QPixmap pixmap(":/imagenex/caballo_o_derecha.png");
        pixmap = pixmap.scaledToWidth(pixmap.width() * 0.78);      
        setPixmap(pixmap);
        moveBy(10, 0);
    }
    else if (event->key() == Qt::Key_W){
        QPixmap pixmap(":/imagenex/caballo_o_arriba.png");
        pixmap = pixmap.scaledToWidth(pixmap.width() * 0.78);
        setPixmap(pixmap);
        moveBy(0, -10);
    }
    else if (event->key() == Qt::Key_S){
        QPixmap pixmap(":/imagenex/caballo_o_abajo.png");
        pixmap = pixmap.scaledToWidth(pixmap.width() * 0.78);
        setPixmap(pixmap);
        moveBy(0, 10);
    }

    // Verificar colisiones con los muros verdaderos
    QList<QGraphicsItem *> collidingItems = QGraphicsPixmapItem::collidingItems();
    foreach (QGraphicsItem *item, collidingItems) {
        if (dynamic_cast<Muro_verdadero *>(item)) {
            // Si hay colisión, restaurar la posición anterior
            setPos(x_anterior, y_anterior);
            break;
        }
    }

}

