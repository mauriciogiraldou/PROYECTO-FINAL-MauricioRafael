#include "escena.h"

Escena::Escena(QObject *parent): QGraphicsScene(parent) {

}

void Escena::mouseMoveEvent(QGraphicsSceneMouseEvent *event){

    QPointF point = event->scenePos();
    qDebug()<<"Mouse position:" <<point;
    event->accept();
}
