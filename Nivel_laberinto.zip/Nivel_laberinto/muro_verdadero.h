#ifndef MURO_VERDADERO_H
#define MURO_VERDADERO_H
#include <QGraphicsEllipseItem>

class Muro_verdadero: public QGraphicsEllipseItem
{
public:
    Muro_verdadero(qreal x, qreal y, qreal ancho, qreal alto);
};

#endif // MURO_VERDADERO_H
